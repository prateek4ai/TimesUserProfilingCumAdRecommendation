"""Utility functions for CTR optimization - Academic + Industry Implementation"""
